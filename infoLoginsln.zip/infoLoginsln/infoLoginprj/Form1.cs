﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace infoLoginprj
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            String catalog = @"Data Source=LAPTOP-HFV6BP2T\SQLEXPRESS;Initial Catalog=Login;Integrated Security=True";
            SqlConnection connect = new SqlConnection(catalog);
            connect.Open();
            String query = "Insert into Login values ('"+textBox1.Text+"','"+textBox2.Text+"')";
            SqlCommand command = new SqlCommand(query,connect);
            int temp = command.ExecuteNonQuery();
            if(temp==1)
            {
                MessageBox.Show("Login suuccessfull!");
            }
            else
            {
                MessageBox.Show("Login failed!");

            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Text = String.Empty;
            textBox2.Text = String.Empty;
        }
    }
}
